<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Admin\CommonController;

use Illuminate\Http\Request;

class ApiController extends CommonController
{
    public function api_upload(Request $request)
    {
        echo 111;
    }


}
